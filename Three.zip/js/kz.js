	//===================================================
	//摇杆
	var kz = document.createElement('canvas');
	kz.height = '200';
	kz.width = '200';
	kz.id = 'yaogan';
	kz.style.position = 'absolute';
	document.documentElement.appendChild(kz);
	vw = window.innerWidth;
	vh = window.innerHeight;
	var YG = document.getElementById('yaogan');
	YGbox = YG.getContext('2d');
	YG.style.width = vh / 2 + 'px';
	YG.style.height = vh / 2 + 'px';
//	YG.style.top = vh - YG.offsetHeight + 'px';
	YG.style.bottom = '0px';
	YG.style.left = '0px';
	//===================================================
	//摇杆
	///=====================================\
	//定义摇杆
	function yg() {
		this.evX = YG.width / 2;
		this.evY = YG.width / 2;
		this.ygxy = [];
	}
	yg.prototype.draw = function() {
		x1 = this.evX, y1 = this.evY, x2 = YG.width / 2;
		xcha = x1 - x2;
		ycha = y1 - x2;
		jvli = Math.pow((xcha * xcha + ycha * ycha), 0.5);
		if (jvli < YG.width / 2 * 0.7) {
			this.ygxy[0] = this.evX;
			this.ygxy[1] = this.evY;
		}
		if (jvli > YG.width / 2 * 0.7) {
			this.evX = this.ygxy[0];
			this.evY = this.ygxy[1];
		}
		this.grd = YGbox.createRadialGradient(this.evX, this.evY, 10, YG.width / 2, YG.width / 2, YG.width / 2);
		this.grd.addColorStop(0, "blue");
		this.grd.addColorStop(1, "rgba(0,0,0,0)");
		YGbox.fillStyle = this.grd /*'#00BFFF'*/ ;
		YGbox.clearRect(0, 0, YG.width, YG.height);
		YGbox.beginPath();
		YGbox.arc(YG.width / 2, YG.width / 2, YG.width / 2, 0, 2 * Math.PI);
		YGbox.closePath();
		YGbox.fill();
		//YGbox.stroke();
		YGbox.beginPath();
		YGbox.fillStyle = '#00BFFF';
		YGbox.arc(this.evX, this.evY, YG.width / 10, 0, 2 * Math.PI);
		YGbox.closePath();
		YGbox.fill();
	}
	yg.prototype.move = function() {}
	var yg = new yg();
	//摇杆的事件
	var sfyz = YG.offsetWidth / YG.width;
	YG.addEventListener('touchmove', function(e) {
		yg.evX = (e.touches[0].clientX - YG.offsetLeft) / sfyz;
		yg.evY = (e.touches[0].clientY - YG.offsetTop) / sfyz;
	});
	YG.addEventListener('touchend', function(e) {
		yg.evX = YG.width / 2;
		yg.evY = YG.width / 2;
	});
	document.onkeydown = function(keyd) {
		//up
		if (keyd.keyCode == 38 || keyd.keyCode == 87) {
			yg.evX = YG.width / 2;
			yg.evY = YG.width / 6;
		} //down
		if (keyd.keyCode == 40 || keyd.keyCode == 83) {
			yg.evX = YG.width / 2;
			yg.evY = YG.width / 6 * 5;
		} //left
		if (keyd.keyCode == 37 || keyd.keyCode == 65) {
			yg.evX = YG.width / 6;
			yg.evY = YG.width / 2;
		} //right
		if (keyd.keyCode == 39 || keyd.keyCode == 68) {
			yg.evX = YG.width / 6 * 5;
			yg.evY = YG.width / 2;
		}
	}
	document.onkeyup = function(keyd) {
		yg.evX = YG.width / 2;
		yg.evY = YG.width / 2;
	}
	function ygsetmove () {
	yg.draw();
	requestAnimationFrame(ygsetmove)
	}ygsetmove();
//==============================//
//以下deom放到主循环里即可
//YG moveONobj
//		//up
//		if (yg.evY < YG.width / 5) {
//			if (F<90) {//one quadrant
//				CZ=camera.position.z-=(10-F*(10/90))*speen;
//				CX = camera.position.x += F*(10/90)*speen;
//			} else if (F<180) {//tow quadrant
//				CZ=camera.position.z+=(F-90)*(10/90)*speen;
//				CX = camera.position.x += (10-(F-90)*(10/90))*speen;
//			}else if (F<270) {//three quadrant
//				CZ=camera.position.z+=(10-(F-180)*(10/90))*speen;
//				CX = camera.position.x -= (F-180)*(10/90)*speen;
//			} else{//four quadrants
//				CZ=camera.position.z-=(F-270)*(10/90)*speen;
//				CX = camera.position.x -=(10-(F-270)*(10/90))*speen;
//			}
//		} //down
//		if (yg.evY > YG.width / 6*4) {
//			if (F<90) {//one quadrant
//				CZ=camera.position.z+=(10-F*(10/90))*speen;
//				CX = camera.position.x -= F*(10/90)*speen;
//			} else if (F<180) {//tow quadrant
//				CZ=camera.position.z-=(F-90)*(10/90)*speen;
//				CX = camera.position.x -= (10-(F-90)*(10/90))*speen;
//			}else if (F<270) {//three quadrant
//				CZ=camera.position.z-=(10-(F-180)*(10/90))*speen;
//				CX = camera.position.x += (F-180)*(10/90)*speen;
//			} else{//four quadrants
//				CZ=camera.position.z+=(F-270)*(10/90)*speen;
//				CX = camera.position.x +=(10-(F-270)*(10/90))*speen;
//			}
//		} //left
//		if (yg.evX < YG.width / 5) {
//			//			camera.position.x-= 10;
//			CYDEG = camera.rotation.y += 0.1;
//		} //right
//		if (yg.evX > YG.width / 6*4) {
//			//			camera.position.x += 10;
//			CYDEG = camera.rotation.y -= 0.1;
//		}