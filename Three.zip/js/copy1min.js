var ms = null;
vars = [0];
window.onload = function() {

	//FPS监视器
	var stats = new Stats();
	stats.setMode(1); // 0: fps, 1: ms
	stats.domElement.style.position = 'absolute';
	// 将stats的界面对应左上角
	stats.domElement.style.left = '0px';
	stats.domElement.style.top = '0px';
	document.getElementById('canvas-frame').appendChild(stats.domElement);
	setInterval(function() {
		stats.begin();
		// 你的每一帧的代码
		stats.end();
	}, 1000 / 60);
	//========
	// 创建一个具有红色背景的渲染器
	var renderer;

	function webglAvailable() {
		try {
			var canvas = document.createElement('canvas');
			return !!(window.WebGLRenderingContext && (
				canvas.getContext('webgl') ||
				canvas.getContext('experimental-webgl')));
		} catch (e) {
			return false;
		}
	}
	if (webglAvailable()) {
		renderer = new THREE.WebGLRenderer({
			alpha: true
		});
	} else {
		renderer = new THREE.CanvasRenderer();
	}
	renderer.setClearColor(0xf0f, 0.0);
	renderer.setSize(window.innerWidth, window.innerHeight);
	//	renderer.getContext('webgl');
	document.body.appendChild(renderer.domElement);
	var scene = new THREE.Scene();
	var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 15000);

	var geometry = new THREE.CubeGeometry(111, 111, 111);
	var material = new THREE.MeshBasicMaterial({
		color: 0xffaadd
	});
	//	var cube = new THREE.Mesh(geometry, material);
	//	cube.position.z=-11;
	//	scene.add(cube);
	//==========
	//光
	//	环境光
	var light = new THREE.AmbientLight(0xdcdcdc, 0.1); // soft white light
	scene.add(light);
	//	平行光
	var directionalLight = new THREE.DirectionalLight(0xfab, 1.5);
	directionalLight.position.set(111, 111, 101);
	scene.add(directionalLight);
	//点光
	var light = new THREE.PointLight(0xffff00, 1, 0);
	light.position.set(0, 130, 30);
	scene.add(light);
	// 实例化一个加载器
	mt = new THREE.MTLLoader();
	mt.load('src/anjila.mtl', function(m) {
		m.preload();
		var loader = new THREE.OBJLoader();
		loader.setMaterials(m);
		// 加载一个资源
		loader.load(
			// 资源链接
			'src/anjila.obj',
			// 资源加载完成后的回调函数
			function(object) {
				ms = object;
				//			ms.position.z = 615;
				ms.rotation.y = 13.14;
				scene.add(object);
			}
		);
	});
	//;;;
	//=======================
	mt1 = new THREE.MTLLoader();
	mt1.load('src/loldt.mtl', function(m) {
		m.preload();
		var loader2 = new THREE.OBJLoader();
		loader2.setMaterials(m);
		loader2.setPath('src/');
		// 加载一个资源
		loader2.load(
			// 资源链接
			'loldt.obj',
			// 资源加载完成后的回调函数
			function(objects) {
				objects.rotation.y = Math.PI / 180 * -45;
				objects.scale.set(1000, 1000, 1000);
				scene.add(objects);
			});
	});
	//	scene.add(loader2);	
	//
	var axisHelper = new THREE.AxisHelper(9999);
	scene.add(axisHelper);
	//===============
	//相机
	camera.position.z = 588;
	camera.position.y = 250;
	camera.rotation.x = Math.PI/180*-15;
	//
	//===================================================
	//摇杆
	vw = window.innerWidth;
	vh = window.innerHeight;
	var YG = document.getElementById('yaogan');
	YGbox = YG.getContext('2d');
	YG.style.width = vw / 3 + 'px';
	YG.style.height = vw / 3 + 'px';
	YG.style.top = vh - YG.offsetHeight + 'px';
	YG.style.left = '0px';
	///=====================================\
	//定义摇杆
	function yg() {
		this.evX = YG.width / 2;
		this.evY = YG.width / 2;
		this.ygxy = [];
	}
	yg.prototype.draw = function() {
		x1 = this.evX, y1 = this.evY, x2 = YG.width / 2;
		xcha = x1 - x2;
		ycha = y1 - x2;
		jvli = Math.pow((xcha * xcha + ycha * ycha), 0.5);
		if (jvli < YG.width / 2 * 0.7) {
			this.ygxy[0] = this.evX;
			this.ygxy[1] = this.evY;
		}
		if (jvli > YG.width / 2 * 0.7) {
			this.evX = this.ygxy[0];
			this.evY = this.ygxy[1];
		}
		this.grd = YGbox.createRadialGradient(this.evX, this.evY, 10, YG.width / 2, YG.width / 2, YG.width / 2);
		this.grd.addColorStop(0, "blue");
		this.grd.addColorStop(1, "rgba(0,0,0,0)");
		YGbox.fillStyle = this.grd /*'#00BFFF'*/ ;
		YGbox.clearRect(0, 0, YG.width, YG.height);
		YGbox.beginPath();
		YGbox.arc(YG.width / 2, YG.width / 2, YG.width / 2, 0, 2 * Math.PI);
		YGbox.closePath();
		YGbox.fill();
		//YGbox.stroke();
		YGbox.beginPath();
		YGbox.fillStyle = '#00BFFF';
		YGbox.arc(this.evX, this.evY, YG.width / 10, 0, 2 * Math.PI);
		YGbox.closePath();
		YGbox.fill();
	}
	yg.prototype.move = function() {}
	var yg = new yg();
	//摇杆的事件
	var sfyz = YG.offsetWidth / YG.width;
	YG.addEventListener('touchmove', function(e) {
		yg.evX = (e.touches[0].clientX - YG.offsetLeft) / sfyz;
		yg.evY = (e.touches[0].clientY - YG.offsetTop) / sfyz;
	});
	YG.addEventListener('touchend', function(e) {
		yg.evX = YG.width / 2;
		yg.evY = YG.width / 2;
	});
	document.onkeydown = function(keyd) {
		//up
		if (keyd.keyCode == 38 || keyd.keyCode == 87) {
			yg.evX = YG.width / 2;
			yg.evY = YG.width / 4;
		} //down
		if (keyd.keyCode == 40 || keyd.keyCode == 83) {
			yg.evX = YG.width / 2;
			yg.evY = YG.width / 4 * 3;
		} //left
		if (keyd.keyCode == 37 || keyd.keyCode == 65) {
			yg.evX = YG.width / 4;
			yg.evY = YG.width / 2;
		} //right
		if (keyd.keyCode == 39 || keyd.keyCode == 68) {
			yg.evX = YG.width / 4 * 3;
			yg.evY = YG.width / 2;
		}
	}
	document.onkeyup = function(keyd) {
		yg.evX = YG.width / 2;
		yg.evY = YG.width / 2;
	}
	var CYDEG = 0;
	CX = 0, CY = 0, CZ = 0, F = 0, d1 = 40 / 360, rup = 0, rdow = 0;
	var p1 = document.getElementById('p1');

	function render() {
		//YG moveONobj
		//up
		if (yg.evY < YG.width / 2.5) {
			camera.position.z -= 20;
			ms.position.z -= 20;
		} //down
		if (yg.evY > YG.width / 1.5) {
			camera.position.z += 20;
			ms.position.z += 20;
		} //left
		if (yg.evX < YG.width / 2.5) {
			camera.position.x -= 20;
			ms.position.x -= 20;
		} //right
		if (yg.evX > YG.width / 1.5) {
			camera.position.x += 20;
			ms.position.x += 20;
		}
		if (ms != null) {}
		yg.draw();
		renderer.render(scene, camera);
		requestAnimationFrame(render);
		dayi();
	}
	render();

	function dayi() {
		F = 180 / Math.PI * -CYDEG - Math.floor(180 / Math.PI * -CYDEG / 360) * 360;
		p1.innerText = 'x:' + Math.floor(CX) + '-y:' + Math.floor(CY) + '-z:' + Math.floor(CZ) + '-cdeg:' + Math.floor(F);
	}
	//	setInterval(dayi,222);
}