let GeometryObj={
	createNew: function(){
		let obj=BaseObject.createNew();

		fileMesh="";
		fileDir="";
		fileMtl="";
		prepar=false; //所有资源是否加载完毕

		obj.ImgFront="";
		obj.ImgBack="";
		obj.ImgFrontBackMove=false;

		obj.TextureFront={}; //if(JSON.stringify(this.uniform.TextureFront) == "{}")
		obj.TextureBack={};

		obj.setImgFront=function(imgFront){
			this.ImgFront=imgFront;
		};
		obj.setImgBack=function(imgBack){
			this.ImgBack=imgBack;
		};
		obj.setImgFrontBackMove=function(move){
			this.ImgFrontBackMove=move;
		};

		obj.getPrepar=function(){
			return this.prepar;
		};
		
		obj.setTexture=function(imgSrc){
			for(var ii=0;ii<obj.buffers.length;ii++){
				obj.buffers[ii].img_texture=initCanvas(imgSrc); //initTextures   initCanvas  initCanvasTexture
				obj.buffers[ii].img_none=false;
			}
		};
		
		obj.calDiamenter=function(){
			var obj_len=parseFloat(0);
			var xl=this.max.x-this.min.x;
			var yl=this.max.y-this.min.y;
			var zl=this.max.z-this.min.z;
			if(xl>yl)obj_len=xl;
			else obj_len=yl;
			if(obj_len>zl)obj_len=zl;
			this.diameter=obj_len;
		};

		obj.initAttrib=function() //声明对象
	    {
	        var a_pos = gl.getAttribLocation(this.program, 'a_pos');
			if (a_pos < 0) {
			  console.log('Failed to get the a_pos location of ' + a_pos);
			  return false;
			}
			var a_uv = gl.getAttribLocation(this.program, 'a_uv');
			if (a_uv < 0) {
			  console.log('Failed to get the a_uv location of ' + a_uv);
			  return false;
			}	
			var a_normal = gl.getAttribLocation(this.program, 'a_normal');
			if (a_normal < 0) {
			  console.log('Failed to get the a_normal location of ' + a_normal);
			}
			this.attrib= {a_pos:a_pos,a_uv:a_uv,a_normal:a_normal};
	    };
		
		obj.init=function(meshfile,program){
			this.param=Scene;
			this.fileMesh=meshfile;
			var pos_xiegang=meshfile.lastIndexOf("\/");
			this.fileDir=meshfile.substring(0,pos_xiegang+1);
			//初始化shader返回shader句柄
			this.program=program;
			//获取shader中的变量句柄
			this.uniform=initUniformThreeTexture(this.program); //获取uniform变量句柄
			this.initAttrib();
			//读取模型文件
			this.ReadObjModel();
		};
		
		obj.ReadObjModel=function(){
			var xhr = new XMLHttpRequest();
			xhr.open('GET', obj.fileMesh, true);
			xhr.responseType = 'text';
			xhr.onload = function(e) {
				var text=this.response.split("\r\n");
				var Version = text[0];
				if(Version.match(/^#\s?3ds\s?Max.*OBJ.*$/)){
					console.log('Check OBJ MESH format Success');
				}
				else console.log('Check OBJ MESH format Failed');

				var sum_vi=parseInt(0);
				var sum_ni=parseInt(0);
				var sum_ti=parseInt(0);
				var sum_fi=parseInt(0);
				
				for(var i=1;i<text.length;i++){
					var buff = text[i];
					
					if(buff.match(/^mtllib\s.*mtl$/)){
						var kpos=buff.indexOf(" ");
						obj.fileMtl=obj.fileDir+buff.substr(kpos+1);
					}
					else if(buff.match(/^#\s?object\s.*$/)){
						var kpos=buff.lastIndexOf(" ");
						obj.CurrentObjectIndex++;
						var CurrentObject={};
						CurrentObject.index=parseInt(obj.CurrentObjectIndex);
						CurrentObject.name=buff.substr(kpos+1);
						var mtl_num=0;
						var mtl_face_postion=new Array();
						var mtl_name=new Array();
						var vi=0;
						var ni=0;
						var ti=0;
						var fi=0;
						var temp_vertices=new Array();
						var temp_normals=new Array();
						var temp_uvs=new Array();
						var index_vertices=new Array();
						var index_normals=new Array();
						var index_uvs=new Array();
						var uv_have=true;
						var n_have=true;
						while(!text[i].match(/^#\s\d+\sfaces$/) && !text[i].match(/^#\s\d+.*\striangles$/) ){
							i++;
							var buffs = text[i];
							if(buffs.match(/^v\s.*$/)){
								var buff_split=buffs.split(" ");
								var tempv={x:buff_split[2],y:buff_split[3],z:buff_split[4]};
								temp_vertices[vi]=tempv;
								vi++;
								sum_vi++;
							}
							else if(buffs.match(/^vn\s.*$/)){
								var buff_split=buffs.split(" ");
								var tempv={x:buff_split[1],y:buff_split[2],z:buff_split[3]};
								temp_normals[ni]=tempv;
								ni++;
								sum_ni++;
							}
							else if(buffs.match(/^vt\s.*$/)){
								var buff_split=buffs.split(" ");
								var tempv={x:buff_split[1],y:buff_split[2]};
								temp_uvs[ti]=tempv;
								ti++;
								sum_ti++;
							}
							else if(buffs.match(/^usemtl\s.*$/)){
								mtl_num++;
								mtl_face_postion[mtl_num-1]=fi;
								var buff_split=buffs.split(" ");
								mtl_name[mtl_num-1]=buff_split[1];
							}
							else if(buffs.match(/^f\s.*$/)){
								var buff_split=buffs.split(" ");
								var temp0=buff_split[1].split("/");
								var temp1=buff_split[2].split("/");
								var temp2=buff_split[3].split("/");
								var tempv={x:temp0[0],y:temp1[0],z:temp2[0]};
								var tempu={x:temp0[1],y:temp1[1],z:temp2[1]};
								var tempn={x:temp0[2],y:temp1[2],z:temp2[2]};

								var v_index={x:parseInt(0),y:parseInt(0),z:parseInt(0)};
								var u_index={x:parseInt(0),y:parseInt(0),z:parseInt(0)};
								var n_index={x:parseInt(0),y:parseInt(0),z:parseInt(0)};

								if(tempu.x=="")uv_have=false;
								if(tempn.x=="")n_have=false;

								
								
								var temp_vv=vi-sum_vi;  //v_index.x=parseInt(tempv.x)-sum_vi+vi-1;
								if(tempv.x<0)v_index.x=parseInt(vi)+parseInt(tempv.x)+1;
								else v_index.x=parseInt(tempv.x)+temp_vv;
								if(tempv.y<0)v_index.y=parseInt(vi)+parseInt(tempv.y)+1;
								else v_index.y=parseInt(tempv.y)+temp_vv;
								if(tempv.z<0)v_index.z=parseInt(vi)+parseInt(tempv.z)+1;
								else v_index.z=parseInt(tempv.z)+temp_vv;

								var temp_uu=ti-sum_ti;
								if(tempu.x<0)u_index.x=parseInt(ti)+parseInt(tempu.x)+1;
								else u_index.x=parseInt(tempu.x)+temp_uu;
								if(tempu.y<0)u_index.y=parseInt(ti)+parseInt(tempu.y)+1;
								else u_index.y=parseInt(tempu.y)+temp_uu;
								if(tempu.z<0)u_index.z=parseInt(ti)+parseInt(tempu.z)+1;
								else u_index.z=parseInt(tempu.z)+temp_uu;

								var temp_nn=ni-sum_ni;
								if(tempn.x<0)n_index.x=parseInt(ni)+parseInt(tempn.x)+1;
								else n_index.x=parseInt(tempn.x)+temp_nn;
								if(tempn.y<0)n_index.y=parseInt(ni)+parseInt(tempn.y)+1;
								else n_index.y=parseInt(tempn.y)+temp_nn;
								if(tempn.z<0)n_index.z=parseInt(ni)+parseInt(tempn.z)+1;
								else n_index.z=parseInt(tempn.z)+temp_nn;

								index_vertices[fi*3+0]=temp_vertices[v_index.x-1];
								index_vertices[fi*3+1]=temp_vertices[v_index.y-1];
								index_vertices[fi*3+2]=temp_vertices[v_index.z-1];
								index_normals[fi*3+0]=temp_normals[n_index.x-1];
								index_normals[fi*3+1]=temp_normals[n_index.y-1];
								index_normals[fi*3+2]=temp_normals[n_index.z-1];

								index_uvs[fi*3+0]=temp_uvs[u_index.x-1];
								index_uvs[fi*3+1]=temp_uvs[u_index.y-1];
								index_uvs[fi*3+2]=temp_uvs[u_index.z-1];
								
								fi++;
								sum_fi++;
							}
						}
						var vindex={v:index_vertices,n:index_normals,u:index_uvs}; 
						CurrentObject.vindex=vindex;
						CurrentObject.mtl_num=mtl_num;
						CurrentObject.mtl_face_postion=mtl_face_postion;
						CurrentObject.mtl_name=mtl_name;
						CurrentObject.vcount=vi;
						CurrentObject.ncount=ni;
						CurrentObject.tcount=ti;
						CurrentObject.fcount=fi;
						CurrentObject.uv_have=uv_have;
						CurrentObject.n_have=n_have;
						obj.Objects[CurrentObject.index]=CurrentObject;
					}
				} //构造函数层级
				obj.build_vbo();
				obj.load_mtl();
			};
			xhr.send();
		};

		//生成标准数组--对于mesh内部细分mtl的，做拆分并重置索引信息--核查顶点索引和normal索引，不一致则合并.
		obj.build_vbo=function(){
			var array_count=0;
			for(var o in this.Objects){
				var fi=this.Objects[o].fcount;
				var vindex=this.Objects[o].vindex;
				
				if(this.Objects[o].mtl_num<=1){
					var index_array=new Array();
					var varray=new Array();
					var uvarray=new Array();
					var narray=new Array();
					for(var i=0;i<vindex.v.length;i++){
						var v0=vindex.v[i];
						var uv0=vindex.u[i];
						var n0=vindex.n[i];
						var found=false;
						var index=-1;
						for(var k=0;k<varray.length;k++){
							if(!typeof(varray[k])=="undefined"){
								var bv=false,bu=false,bn=false;
								if(v0.x==varray[k].x && v0.y==varray[k].y && v0.z==varray[k].z)bv=true;
								if(uv0.x==uvarray[k].x && uv0.y==uvarray[k].y)bu=true;
								if(n0.x==narray[k].x && n0.y==narray[k].y && n0.z==narray[k].z)bn=true;
								if(bv && bu && bn) {
									found=true;
									index=k;
									break;
								}
							}else break;
						}
						
						if(found){
							index_array.push(index);
						}else{
							index_array.push(varray.length);
							varray.push(v0);
							uvarray.push(uv0);
							narray.push(n0);
						}
					}
					//push到最终mesh数组----> 绑定到顶点缓冲区
					var temp_rs={v:varray,uv:uvarray,n:narray,index:index_array,mtl:this.Objects[o].mtl_name[0],
						uv_have:this.Objects[o].uv_have,n_have:this.Objects[o].n_have};
					this.Objects_rs[array_count]=temp_rs;
					array_count++;
				}
				else {
					//根据mtl拆分mesh为多个子对象
					var pre_count=0;
					for(var m=0;m<this.Objects[o].mtl_num;m++){
						var count=0;
						if(m<this.Objects[o].mtl_num-1)
							count=this.Objects[o].mtl_face_postion[m+1]-this.Objects[o].mtl_face_postion[m];
						else
							count=fi-this.Objects[o].mtl_face_postion[m];

						var index_array=new Array();
						var varray=new Array();
						var uvarray=new Array();
						var narray=new Array();
						var prenum=parseInt(pre_count)*3;
						var sumcount=count*3;
						for(var i=0;i<sumcount;i++){
							var ii=prenum+parseInt(i);
							var v0=vindex.v[ii];
							
							//if(typeof(v0)=="undefined")
						 	//var sdfsd=0;
						 	
							var uv0=vindex.u[ii];
							var n0=vindex.n[ii];
							var found=false;
							var index=-1;
							for(var k=0;k<varray.length;k++){
								var testv=false;
								var testu=false;
								var testn=false;
								if(typeof(varray[k])=="undefined")testv=true;
								if(typeof(uvarray[k])=="undefined")testu=true;
								if(typeof(narray[k])=="undefined")testn=true;

								if(!testv && !testu && !testn){
									var bv=false,bu=false,bn=false;
									if(v0.x==varray[k].x && v0.y==varray[k].y && v0.z==varray[k].z)bv=true;
									if(uv0.x==uvarray[k].x && uv0.y==uvarray[k].y)bu=true;
									if(n0.x==narray[k].x && n0.y==narray[k].y && n0.z==narray[k].z)bn=true;
									if(bv && bu && bn) {
										found=true;
										index=k;
										break;
									}
								}else break;
							}
							if(found){
								index_array.push(index);
							}else{
								index_array.push(varray.length);
								varray.push(v0);
								uvarray.push(uv0);
								narray.push(n0);
							}
						}
						var temp_rs={v:varray,uv:uvarray,n:narray,index:index_array,mtl:this.Objects[o].mtl_name[m],
							uv_have:this.Objects[o].uv_have,n_have:this.Objects[o].n_have};
						this.Objects_rs[array_count]=temp_rs;
						array_count++;
						pre_count+=count;
					}
				}
			}
		};

		obj.load_mtl=function(){
			var xhr = new XMLHttpRequest();
			xhr.open('GET', obj.fileMtl, true);
			xhr.responseType = 'text';
			xhr.onload = function(e) {
				var text=this.response.split("\r\n");

				for(var i=0;i<text.length;i++){
					var buff0 = text[i];
					if(buff0.match(/^newmtl\s.*$/)){
						var buff_split0=buff0.split(" ");
						i++;
						var map_Kd = "0";
						var Kd ={x:parseFloat(0),y:parseFloat(0),z:parseFloat(0)};
						var alpha=parseFloat(1.0);
						while(!text[i].match(/^[\r\n]?$/)){
							var buff = text[i];
							if(buff.match(/^\tKd\s.*$/)){
								var buff_split=buff.split(" ");
								Kd.x=buff_split[buff_split.length-3];
								Kd.y=buff_split[buff_split.length-2];
								Kd.z=buff_split[buff_split.length-1];
							}
							if(buff.match(/^\tmap_Kd\s.*$/)){
								var buff_split=buff.split(" ");
								map_Kd=buff_split[buff_split.length-1];
							}
							if(buff.match(/^\td\s.*$/)){
								var buff_split=buff.split(" ");
								alpha=buff_split[buff_split.length-1];
							}
							i++;
						}
						obj.mtls[buff_split0[1]]={Kd:Kd,map_Kd:map_Kd,alpha:alpha};
					}
				}
				obj.initVertexBuffers();
				obj.init_texture_buffer();
				//计算长轴尺寸
				obj.calDiamenter();
				delete obj.Objects;
				delete obj.Objects_rs;
				obj.prepar=true;
			}; 
			xhr.send();
		}

		obj.initVertexBuffers=function(){
			for(var o in this.Objects_rs){
				var len_index=this.Objects_rs[o].index.length;
				var len_v=this.Objects_rs[o].v.length;
				var len_uv=this.Objects_rs[o].uv.length;
				var len_n=this.Objects_rs[o].n.length;
				var array_index=new Uint16Array(len_index);
				var array_v=new Float32Array(len_v*3);
				var array_uv=new Float32Array(len_uv*2);
				var array_n=new Float32Array(len_n*3);
				var img_texture={};
				var diffuse_color=new Float32Array(4);
				
				
				for(var i=0;i<len_index;i++){
					array_index[i]=this.Objects_rs[o].index[i];
				}
				for(var i=0;i<len_v;i++){
					array_v[i*3+0]=this.Objects_rs[o].v[i].x;
					array_v[i*3+1]=this.Objects_rs[o].v[i].y;
					array_v[i*3+2]=this.Objects_rs[o].v[i].z;
					if(array_v[i*3+0]<this.min.x)this.min.x=array_v[i*3+0];
					if(array_v[i*3+0]>this.max.x)this.max.x=array_v[i*3+0];
					if(array_v[i*3+1]<this.min.y)this.min.y=array_v[i*3+1];
					if(array_v[i*3+1]>this.max.y)this.max.y=array_v[i*3+1];
					if(array_v[i*3+2]<this.min.z)this.min.z=array_v[i*3+2];
					if(array_v[i*3+2]>this.max.z)this.max.z=array_v[i*3+2];
				}
				//uv_have:this.Objects[o].uv_have,n_have:this.Objects[o].n_have
				if(this.Objects_rs[o].uv_have){
					for(var i=0;i<len_uv;i++){
						array_uv[i*2+0]=this.Objects_rs[o].uv[i].x;
						array_uv[i*2+1]=this.Objects_rs[o].uv[i].y;
					}
				}
				if(this.Objects_rs[o].n_have){
					for(var i=0;i<len_n;i++){
						array_n[i*3+0]=this.Objects_rs[o].n[i].x;
						array_n[i*3+1]=this.Objects_rs[o].n[i].y;
						array_n[i*3+2]=this.Objects_rs[o].n[i].z;
					}
				}
				
				var b_pos=initArrayBuffer('a_pos', array_v);
				var b_uv=initArrayBuffer('a_uv', array_uv);
				var b_normal=initArrayBuffer('a_normal', array_n);
				var b_index=initElementArrayBuffer(array_index);
				
				var buffers={pos:b_pos,uv:b_uv,normal:b_normal,index:b_index,img_texture:img_texture,
				pic:this.Objects_rs[o].mtl,length:len_index,img_none:true,diffuse_color:diffuse_color,
				uv_have:this.Objects_rs[o].uv_have,n_have:this.Objects_rs[o].n_have};
				
				this.buffers.push(buffers);
			}
		}
		obj.init_texture_buffer=function(){
			this.sample_texture=getUniform('Texture',this.program);		
			for(var oo in this.buffers){
				//初始化每个mesh对应的纹理，已有共用纹理不再重新创建
				var find=false;
				var temp_pic=this.buffers[oo].pic;
				var temp_map_Kd=this.mtls[temp_pic].map_Kd;
				var temp_Kd=this.mtls[temp_pic].Kd;
				var temp_alpha=this.mtls[temp_pic].alpha;
				
				this.buffers[oo].diffuse_color[0]=temp_Kd.x;
				this.buffers[oo].diffuse_color[1]=temp_Kd.y;
				this.buffers[oo].diffuse_color[2]=temp_Kd.z;
				this.buffers[oo].diffuse_color[3]=1.0; //该透明度待扩充--解析mtl的Tr参数
				this.buffers[oo].alpha=temp_alpha;
					
				for(var p in this.buffers){
					if(!isEmptyObject(this.buffers[p].img_texture)){
						var p_pic=this.buffers[p].pic;
						var p_map_Kd=this.mtls[p_pic].map_Kd;
						if(this.buffers[oo].pic==this.buffers[p].pic || temp_map_Kd ==p_map_Kd){
							this.buffers[oo].img_texture=this.buffers[p].img_texture;
							this.buffers[oo].img_none=false;
							find=true;
							break;
						}
					}
				}
				if(!find){
					if(temp_map_Kd!="0"){
						var img_file=this.fileDir+temp_map_Kd;
						this.buffers[oo].img_texture=initTextures(img_file);
						this.buffers[oo].img_none=false;
					}
				}
			}
			if(this.uniform.TextureFront != null) this.TextureFront=initTextures(this.ImgFront);
			if(this.uniform.TextureBack != null) this.TextureBack=initTextures(this.ImgBack);
		};
		
		obj.Render=function(){
			gl.program = this.program;
			gl.useProgram(this.program);
			//公共Joints
			setUniformThreeTexture(this,Scene);
			
			for(var i in this.buffers){
				if(this.uniform.diffuse_color != undefined)
					gl.uniform4fv(this.uniform.diffuse_color,this.buffers[i].diffuse_color );
				if(!this.buffers[i].img_none){
					gl.activeTexture(gl.TEXTURE0);
					gl.bindTexture(gl.TEXTURE_2D, this.buffers[i].img_texture);
					gl.uniform1i(this.sample_texture, 0);
					gl.uniform1i(this.uniform.img_none, 0);
				}else{
					gl.uniform1i(this.uniform.img_none, parseInt(1));
				}
				
				gl.enableVertexAttribArray(this.attrib.a_pos);
				gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i].pos);
				gl.vertexAttribPointer(this.attrib.a_pos, 3, gl.FLOAT, false, 0, 0);

				if(this.buffers[i].uv_have){
					gl.enableVertexAttribArray(this.attrib.a_uv);				
					gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i].uv);
					gl.vertexAttribPointer(this.attrib.a_uv, 2, gl.FLOAT, false, 0, 0);
				}
				if(this.buffers[i].n_have && this.attrib.a_normal>0){
					gl.enableVertexAttribArray(this.attrib.a_normal);			
					gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[i].normal);
					gl.vertexAttribPointer(this.attrib.a_normal, 3, gl.FLOAT, false, 0, 0);
				}
				gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buffers[i].index);
				gl.drawElements(gl.TRIANGLES, this.buffers[i].length, gl.UNSIGNED_SHORT, 0);

				/*
				if(this.buffers[i].png){
					gl.disable(gl.BLEND); 
				}
				*/
				
				gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
				gl.disableVertexAttribArray(this.attrib.a_pos);
				gl.disableVertexAttribArray(this.attrib.a_uv);
				if(this.attrib.a_normal>0)
					gl.disableVertexAttribArray(this.attrib.a_normal);
			}
			gl.useProgram(null);
		};

		obj.destroy=function(){
			for(var i in this.buffers){
				if(!this.buffers[i].img_none){
					gl.deleteTexture(this.buffers[i].img_texture);
					this.buffers[i].img_texture=null;
				}
				gl.deleteBuffer(this.buffers[i].pos);
				this.buffers[i].pos=null;
				if(this.buffers[i].uv_have){
					gl.deleteBuffer(this.buffers[i].uv);
					this.buffers[i].uv=null;
				}
				if(this.buffers[i].n_have){
					gl.deleteBuffer(this.buffers[i].normal);
					this.buffers[i].normal=null;
				}
				gl.deleteBuffer(this.buffers[i].index);
				this.buffers[i].index=null;
			}
		};
		
		return obj;
	}
};

