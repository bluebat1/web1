if (navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BorwserNG|WebOS|SymBian|Windows Phone)/i)) {
	pt = true;
	/*触屏端*/
} else {
	/*pc端*/
	pt = false;
}
//主类
var lk=(function lk() {
	this.g=0;
})
//====================================================//
//鼠标移至、离开dom对象的事件
lk.prototype.overout = function(obj, overfn, outfn) {
		this.obj = obj;
		this.obj.onmouseover = function() {
			return overfn();
		}
		this.obj.onmouseout = function() {
			return outfn();
		}
	}
	//在dom元素上移动时触发
lk.prototype.move = function(obj, fn) {
		this.obj = obj;
		if (pt) {
			this.obj.ontouchmove = function(e) {
				return fn(e);
			}
		} else {
			this.obj.onmousemove = function(e) {
				return fn(e);
			}
		}
	}
	///////////////////
lk.prototype.ad = function(n) { //角度转弧度
	return Math.PI / 180 * n;
}
lk.prototype.da = function(n) { //弧度转角度
		return 180 / Math.PI * n;
	}
	//在dom元素上滑动时触发
	//鼠标须按下左键再滑动
lk.prototype.moveUDLR = function(obj, fnup, fndow, fnleft, fnright) {
		this.obj = obj;
		var a = 0,
			b = 0,
			xa = 0,
			ya = 0,
			xb = 0,
			yb = 0;
		if (pt) {
			this.obj.ontouchstart = function(e) {
				xa = e.targetTouches[0].clientX;
				ya = e.targetTouches[0].clientY;
				this.ontouchmove = function(ea) {
					xb = ea.targetTouches[0].clientX;
					yb = ea.targetTouches[0].clientY;
					yt = ya - yb;
					xt = xa - xb;
					if (xt < -10) {
						fnleft(obj, xt, xb, yb);
					}
					if (xt > 11) {
						fnright(obj, xt, xb, yb);
					};
					if (yt > 10) {
						fnup(obj, yt, xb, yb);
					}
					if (yt < -10) {
						fndow(obj, yt, xb, yb);
					}
				}
			}
			this.obj.ontouchend = function() {
				this.ontouchmove = function() {}
			}
		} else {
			this.obj.onmousedown = function(e) {
				xa = e.clientX;
				ya = e.clientY;
				this.onmousemove = function(ea) {
					xb = ea.clientX;
					yb = ea.clientY;
					xt = xa - xb;
					yt = ya - yb;
					if (xt < -10) {
						fnleft(obj, xt, xb, yb);
					}
					if (xt > 11) {
						fnright(obj, xt, xb, yb);
					};
					if (yt > 10) {
						fnup(obj, yt, xb, yb);
					}
					if (yt < -10) {
						fndow(obj, yt, xb, yb);
					}
				}
			}
			this.obj.onmouseup = function() {
				this.onmousemove = function() {};
			}
		}
	}
	//在dom元素上按下时触发
lk.prototype.ondown = function(obj, fn) {
		if (pt) {
			obj.ontouchstart = function(e) {
				fn(e, obj);
			}
		} else {
			obj.onmousedown = function(e) {
				fn(e, obj);
			}
		}
	}
	//dom元素的弹起事件
lk.prototype.onup = function(obj, fn) {
		if (pt) {
			obj.ontouchend = function() {
				fn(obj);
			}
		} else {
			obj.onmouseup = function() {
				fn(obj);
			}
		}
	}
	//====================================================//
	//异步加载文件
lk.prototype.ajax = function(opt) {
		var opt = opt || {};
		opt.method = opt.method.toUpperCase() || 'GET';
		opt.url = opt.url || '';
		opt.async = opt.async || true;
		opt.data = opt.data || null;
		opt.success = opt.success || function() {};
		var xmlHttp = null;
		if (XMLHttpRequest) {
			xmlHttp = new XMLHttpRequest();
		} else {
			xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
		}
		var params = [];
		for (var key in opt.data) {
			params.push(key + '=' + opt.data[key]);
		}
		var postData = params.join('&');
		if (opt.method.toUpperCase() === 'POST') {
			xmlHttp.open(opt.method, opt.url, opt.async);
			xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
			xmlHttp.send(postData);
		} else if (opt.method.toUpperCase() === 'GET') {
			xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
			xmlHttp.send(null);
		}
		xmlHttp.onreadystatechange = function() {
			if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
				opt.success(xmlHttp.responseText);
			}
		}
	}
	//=====================================================//
	//进度条
lk.prototype.loading = function(html, bol) {
		var diva = document.createElement('div');
		var div = document.createElement('div');
		diva.style.position = 'absolute';
		diva.style.zIndex = '999';
		diva.style.height = innerHeight + 'px';
		diva.style.width = innerWidth + 'px';
		div.style.position = 'fixed';
		div.innerHTML = html;
		diva.appendChild(div);
		document.body.appendChild(diva);
		div.style.top = innerHeight / 2 - div.offsetHeight / 2 + 'px';
		div.style.left = innerWidth / 2 - div.offsetWidth / 2 + 'px';
		bol(diva);
	}
	//批量加载img
lk.prototype.loadimg = function(imgsrcarr, fn, fnError) {
		var imgs = [];
		var _count = 0;
		for (i = 0; i < imgsrcarr.length; i++) {
			var _oImg = new Image;
			_oImg.src = imgsrcarr[i];
			imgs.push(_oImg);
			(function(index) {
				_oImg.onload = function() {
					_count++;
					if (_count == imgsrcarr.length) {
						fn(imgs);
					}
				}
				_oImg.onerror = function() {
					fnError && fnError();
				}
			})(i);
		}
	}
	//定义canvas2d的image对象-定位在左上角
lk.prototype.newimg = function(img, imgx, imgy, imgw, imgh, cx, cy, cw, ch, r, x, y) {
		this.img = img;
		this.imgx = imgx;
		this.imgy = imgy;
		this.imgw = imgw;
		this.imgh = imgh;
		this.cx = cx;
		this.cy = cy;
		this.cw = cw;
		this.ch = ch;
		this.r = r;
		this.x = x;
		this.y = y;
		this.draw = function(gl) {
			gl.save();
			gl.translate(this.x,this.y);
			gl.rotate(this.r);
			gl.drawImage(this.img, this.imgx, this.imgy, this.imgw, this.imgh, this.cx + intx, this.cy + inty, this.cw, this.ch);
			gl.restore();
		}
	}
	//定义canvas2d的image对象-定位在中心
lk.prototype.newimgb = function(img, imgx, imgy, imgw, imgh, cx, cy, cw, ch, r, x, y) {
		this.img = img;
		this.imgx = imgx;
		this.imgy = imgy;
		this.imgw = imgw;
		this.imgh = imgh;
		this.cx = cx;
		this.cy = cy;
		this.cw = cw;
		this.ch = ch;
		this.r = r;
		this.x = x;
		this.y = y;
		this.draw = function(gl) {
			gl.save();
			gl.translate(this.x,this.y);
			gl.rotate(this.r);
			gl.drawImage(this.img, this.imgx, this.imgy, this.imgw, this.imgh, this.cx - this.cw / 2 + intx, this.cy - this.ch / 2 + inty, this.cw, this.ch);
			gl.restore();
		}
	}
	/////////////////////////////////////////
	////////////////////////////////////////
lk.prototype.collideb = function(x, y, z, v) {
		if (Math.abs(x) < 1) {
			x = 1;
		}
		if (Math.abs(y) < 1) {
			y = 1;
		}
		if (Math.abs(z) < 1) {
			z = 1;
		}
		if (Math.abs(x) * Math.abs(y) * Math.abs(z) < v) {
			return true;
		} else {
			return false;
		}
	}
	////////////////////////////////////////
	//碰撞检测
lk.prototype.collide = function(x, y, z, v) {
		if (Math.sqrt(x * x + y * y + z * z) < v) {
			return true;
		} else {
			return false;
		}
	}
	//创建一个canvas
lk.prototype.newcanvas = function(id, cc, types, fn) {
		this.types = types;
		var canvas = document.createElement('canvas');
		canvas.id = id;
		if (types) {
			if (types.w) {
				canvas.width = types.w;
			}
			if (types.h) {
				canvas.height = types.h;
			}
			if (types.sw) {
				canvas.style.width = this.types.sw;
			}
			if (types.sh) {
				canvas.style.height = this.types.sh;
			}
			if (types.top) {
				canvas.style.top = types.top;
			}
			if (types.left) {
				canvas.style.left = types.left;
			}
		}
		document.body.appendChild(canvas);
		var cxt = canvas.getContext(cc);
		/*return*/ fn(cxt, canvas);
	}
	/////////////////////////////////
	//////////////////////////////////
	//摇杆
lk.prototype.newyg = function(id, types, fn) {
		//	this.types=types;
		//创建摇杆画布标签
		var canvas = document.createElement('canvas');
		canvas.id = id;
		canvas.width = types.w || 200;
		canvas.height = types.h || 200;
		canvas.style.position = 'absolute';
		canvas.style.width = types.sw || '200px';
		canvas.style.height = types.sh || '200px';
		canvas.style.bottom = types.bottom || '0px';
		canvas.style.left = types.left || '0px';
		document.body.appendChild(canvas);
		//获取摇杆上下文
		var cxt = canvas.getContext('2d');
		//获取摇杆实际尺寸与摇杆定义尺寸的比值
		var inxy = canvas.offsetWidth / canvas.width;
		var up = this.up,
			down = this.down,
			left = this.left,
			right = this.right;
		var evX = 0,
			evY = 0;
		//判断设备平台
		//移动端
		if (pt) {
			canvas.ontouchstart = function() {
				canvas.style.display = '';
			}
			canvas.ontouchmove = function(e) {
				yg.evX = (e.touches[0].clientX - canvas.offsetLeft) / inxy;
				yg.evY = (e.touches[0].clientY - canvas.offsetTop) / inxy;
			}
			canvas.ontouchend = function() {
				yg.evX = canvas.width / 2;
				yg.evY = canvas.width / 2;
				canvas.style.display = 'none';
			}
		} else { //pc端
			canvas.onmousedown = function() {
				canvas.style.display = '';
			}
			canvas.onmousemove = function() {
				yg.evX = (e.clientX - canvas.offsetLeft) / inxy;
				yg.evY = (e.clientY - canvas.offsetTop) / inxy;
			}
			canvas.onmouseup = function() {
				yg.evX = canvas.width / 2;
				yg.evY = canvas.width / 2;
				canvas.style.display = 'none';
			}
		}
		////////////////////////////////////////
		////////////////////////////////////////
		document.onkeydown = function(keyd) {
			
			//up
			if (keyd.keyCode == 38 || keyd.keyCode == 87) {
				yg.evX = canvas.width / 2;
				yg.evY = canvas.width / 6;
			} //down
			if (keyd.keyCode == 40 || keyd.keyCode == 83) {
				yg.evX = canvas.width / 2;
				yg.evY = canvas.width / 6 * 5;
			} //left
			if (keyd.keyCode == 37 || keyd.keyCode == 65) {
				yg.evX = canvas.width / 6;
				yg.evY = canvas.width / 2;
			} //right
			if (keyd.keyCode == 39 || keyd.keyCode == 68) {
				yg.evX = canvas.width / 6 * 5;
				yg.evY = canvas.width / 2;
			}
		}
		document.onkeyup = function(keyd) {
			yg.evX = canvas.width / 2;
			yg.evY = canvas.width / 2;
		}

		function ygforset() {
//			cxt.clearRect(0, 0, canvas.width, canvas.height);
//			ygforsetqa = requestAnimationFrame(ygforset)
		}
		ygforset();
		fn(cxt, canvas) || fn;
	}




//fps监视
lk.prototype.fpsset=function() {
	var divs;
	function f() {
	var div=document.createElement('div');
	div.style.zIndex='111';
	div.style.color='red';
	divtxt=div.innerText='99';
	document.body.appendChild(div);
	divs=div;
	}f();
	var fpss=0;
	setInterval(function () {
		divs.innerText=fpss+'fps';
		fpss=0;
	},1000)
	function thisfor () {
		fpss++;
		requestAnimationFrame(thisfor,document.body)
	}thisfor()
	
}
///////////////////////
window.onmessage=function () {
	console.log(0);
}
	//===============================
	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////
	//构建lk类
var lk = new lk();
console.log('lk-class-1.0 v1.3');