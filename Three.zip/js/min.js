var ms = null;
vars = [0];
window.onload = function() {

	//FPS监视器
	var stats = new Stats();
	stats.setMode(1); // 0: fps, 1: ms
	stats.domElement.style.position = 'absolute';
	// 将stats的界面对应左上角
	stats.domElement.style.left = '0px';
	stats.domElement.style.top = '0px';
	document.getElementById('canvas-frame').appendChild(stats.domElement);
	setInterval(function() {
		stats.begin();
		// 你的每一帧的代码
		stats.end();
	}, 1000 / 60);
	//========
	// 创建一个具有红色背景的渲染器
	var renderer;

	function webglAvailable() {
		try {
			var canvas = document.createElement('canvas');
			return !!(window.WebGLRenderingContext && (
				canvas.getContext('webgl') ||
				canvas.getContext('experimental-webgl')));
		} catch (e) {
			return false;
		}
	}
	if (webglAvailable()) {
		renderer = new THREE.WebGLRenderer({
			alpha: true
		});
	} else {
		renderer = new THREE.CanvasRenderer();
	}
	renderer.setClearColor(0xf0f, 0.0);
	renderer.setSize(window.innerWidth, window.innerHeight);
	//	renderer.getContext('webgl');
	document.body.appendChild(renderer.domElement);
	var scene = new THREE.Scene();
	var camera = new THREE.PerspectiveCamera(88, window.innerWidth / window.innerHeight, 1, 99999);
	var geometry = new THREE.CubeGeometry(111, 111, 111);
	var material = new THREE.MeshBasicMaterial({
		color: 0xffaadd
	});
	//==========
	//光
	//	环境光
	var light = new THREE.AmbientLight(0xdcdcdc, 0.5); // soft white light
	scene.add(light);
	//	平行光
	var directionalLight = new THREE.DirectionalLight(0xEEE8AA, 1);
	scene.add(directionalLight);
	//点光
	//	var light = new THREE.PointLight('red', 0.5);
	//	light.position.set(0, 0, 0);
	//	scene.add(light);
	// 实例化一个加载器
	mt = new THREE.MTLLoader();
	mt.load('src/she-shou.mtl', function(m) {
		m.preload();
		var loader = new THREE.OBJLoader();
		loader.setMaterials(m);
		// 加载一个资源
		loader.load(
			// 资源链接
			'src/she-shou.obj',
			// 资源加载完成后的回调函数
			function(object) {
				object.scale.set(10, 10, 10);
				ms = object;
				ms.position.z = -215;
				scene.add(object);
				i=0;
				setInterval(function () {
					i++;
					if (i<6) {
						ms.rotation.y += 0.01;
					} else{
						ms.rotation.y -= 0.01;
						if (i==10) {
							i=0;
						}
					}
				},100)
			}
		);
	});
	//;;;
	//=======================
	var a;
	mt1 = new THREE.MTLLoader();
	mt1.load('src/loldt.mtl', function(m) {
		m.preload();
		var loader2 = new THREE.OBJLoader();
		loader2.setMaterials(m);
		loader2.setPath('src/');
		// 加载一个资源
		loader2.load(
			// 资源链接
			'loldt.obj',
			// 资源加载完成后的回调函数
			function(objects) {
				a = objects;
				objects.rotation.y = Math.PI / 180 * -45;
				objects.scale.set(1000, 1000, 1000);
				scene.add(objects);
			});
	});
	
	//	scene.add(loader2);
	mt2 = new THREE.MTLLoader();
	mt2.load('src/shuijing1.mtl', function(m) {
		m.preload();
		loader2 = new THREE.OBJLoader();
		loader2.setMaterials(m);
		loader2.setPath('src/');
		// 加载一个资源
		loader2.load(
			// 资源链接
			'shuijing1.obj',
			// 资源加载完成后的回调函数
			function(objects) {
				var box = new THREE.BoxHelper( objects );
				objects.add(box);
				aa = setInterval(function() {
					objects.rotation.y += 0.1;
				}, 33);
				objects.position.x = -400;
				objects.position.y = 1;
				objects.scale.set(100, 100, 100);
				scene.add(objects);
			});
	});
	var material = new THREE.MeshBasicMaterial();
	lo = new THREE.TextureLoader();
	material.map = lo.load('img/03.jpg');
	material.side = THREE.DoubleSide;
	var geometry = new THREE.CylinderGeometry(22222, 22222, 3120, 1132);
	var cylinder = new THREE.Mesh(geometry, material);
	cylinder.position.y = 1000;
	scene.add(cylinder);
	//==========
	var fbx2 = new THREE.FBXLoader();
		// 加载一个资源
		fbx2.load(
			// 资源链接
			'./src/shenpanz2.fbx',
			// 资源加载完成后的回调函数
			function(objects1) {
//				objects1.position.z=100;
				objects1.scale.set(100,100,100);
				scene.add(objects1);
			});
	//坐标轴
	var axisHelper = new THREE.AxisHelper(99999);
	scene.add(axisHelper);
	//===============
	//相机
	camera.position.z = 441;
	camera.position.y = 111;
	//	camera.rotation.x = 1;
	//
	//	//===================================================
	var CYDEG = 0,
		CX = 0,
		CY = 0,
		CZ = 0,
		F = 0,
		d1 = 20 / 360,
		rup = 0,
		rdow = 0,
		speen = 3;
	var p1 = document.getElementById('p1');
	bf = 0;

	function render() {
		//YG moveONobj
		//up
		if (yg.evY < YG.width / 5) {
			if (bf > 22) {

				bf = 0;
			} else {
				bf += 1;

				if (F < 90) { //one quadrant
					CZ = camera.position.z -= (10 - F * (10 / 90)) * speen;
					CX = camera.position.x += F * (10 / 90) * speen;
				} else if (F < 180) { //tow quadrant
					CZ = camera.position.z += (F - 90) * (10 / 90) * speen;
					CX = camera.position.x += (10 - (F - 90) * (10 / 90)) * speen;
				} else if (F < 270) { //three quadrant
					CZ = camera.position.z += (10 - (F - 180) * (10 / 90)) * speen;
					CX = camera.position.x -= (F - 180) * (10 / 90) * speen;
				} else { //four quadrants
					CZ = camera.position.z -= (F - 270) * (10 / 90) * speen;
					CX = camera.position.x -= (10 - (F - 270) * (10 / 90)) * speen;
				}
			}
		} //down
		if (yg.evY > YG.width / 6 * 4) {
			if (F < 90) { //one quadrant
				CZ = camera.position.z += (10 - F * (10 / 90)) * speen;
				CX = camera.position.x -= F * (10 / 90) * speen;
			} else if (F < 180) { //tow quadrant
				CZ = camera.position.z -= (F - 90) * (10 / 90) * speen;
				CX = camera.position.x -= (10 - (F - 90) * (10 / 90)) * speen;
			} else if (F < 270) { //three quadrant
				CZ = camera.position.z -= (10 - (F - 180) * (10 / 90)) * speen;
				CX = camera.position.x += (F - 180) * (10 / 90) * speen;
			} else { //four quadrants
				CZ = camera.position.z += (F - 270) * (10 / 90) * speen;
				CX = camera.position.x += (10 - (F - 270) * (10 / 90)) * speen;
			}
		} //left
		if (yg.evX < YG.width / 5) {
			//			camera.position.x-= 10;
			CYDEG = camera.rotation.y += 0.1;
		} //right
		if (yg.evX > YG.width / 6 * 4) {
			//			camera.position.x += 10;
			CYDEG = camera.rotation.y -= 0.1;
		}
		//=================================================\\
		renderer.render(scene, camera);
		requestAnimationFrame(render);
		dayi();
	}
	render();

	function dayi() {
		F = 180 / Math.PI * -CYDEG - Math.floor(180 / Math.PI * -CYDEG / 360) * 360;
		p1.innerText = 'x:' + Math.floor(CX) + '-y:' + Math.floor(CY) + '-z:' + Math.floor(CZ) + '-cdeg:' + Math.floor(F);
	}
	//	setInterval(dayi,222);
	window.onmousewheel = function(e) {
		if (e.wheelDelta < 0) {
			camera.position.y += 22;
		} else {
			camera.position.y -= 22;
		}
	}
}