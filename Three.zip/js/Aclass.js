function a2d (n) {//角度转弧度
	return Math.PI/180*n;
}
function d2a (n) {//弧度转角度
	return 180/Math.PI*n;
}